#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "heap.h"

/* Your Heap implementation here */
// Some of these functions are not mentioned in the writeup
// but are useful helper functions that you can use 


void swap(Heap* h, int index1, int index2) {

}

void expandCapacity(Heap* h) {

}

void bubbleUp(Heap* h, int index) {
	if (index == 1){
		return;
	}
	else if (h->elements[index]->key < h->elements[(index-1)/2]->key){
		swap(h,index,(index-1)/2);
	}
	bubbleUp(h,(index-1)/2);
}

void add(Heap* h, int k, char* val) {
	if (h->capacity == h->size){
		expandCapacity(h);
		h->elements[h->size]->key = k;
		h->elements[h->size]->value=val;
	}
	else{
		h->elements[h->size]->key = k;
		h->elements[h->size]->value=val;
		bubbleUp(h,h->size);
	}
}

void bubbleDown(Heap* h, int index) {

}

char* removeMin(Heap* h) {
	return NULL;
}

bool isHeapAt(Heap* h, int index) {
	return NULL;
}

void cleanupHeap(Heap* h) {
	free(h);
}

void printHeap(Heap* h) {
	
}

Heap* makeHeap(int capacity) {
	Heap* h;
	h=calloc(1,sizeof(0));
	h->elements=calloc(capacity,sizeof(Entry*));
}

char* peek(Heap* heap) {
	if (heap->size == 0){
		return NULL;
	}
	else{
		return heap->elements[0]->value;
	}
}

int size(Heap* heap) {
	return heap->size;
}

